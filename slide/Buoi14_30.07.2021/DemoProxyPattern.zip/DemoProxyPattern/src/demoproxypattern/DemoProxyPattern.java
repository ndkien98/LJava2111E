/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demoproxypattern;

/**
 *
 * @author KhuongVD1
 */
public class DemoProxyPattern {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Init proxy Image: ");
        ProxyImage proxyimage = new ProxyImage("https://vnexpress.net");
        
        System.out.println("Call Real service lần 1");
        proxyimage.showImage();
        
        System.out.println("Call Real service lần 2");
        proxyimage.showImage();
    }
    
}
