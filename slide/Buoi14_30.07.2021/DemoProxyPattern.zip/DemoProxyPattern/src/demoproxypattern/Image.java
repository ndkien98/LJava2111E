
package demoproxypattern;

public interface Image {
    void showImage();
}
