/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demoproxypattern;

/**
 *
 * @author KhuongVD1
 */
public class RealImage implements Image {
   private String url;
   
   public RealImage(String url){
       this.url = url;
       System.out.println("Image Load:" + this.url);
   }
   
   public void showImage(){
       System.out.println("Image showed: " + this.url);
   }
}
