/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demoobserverpattern;

/**
 *
 * @author KhuongVD1
 */
public class EmailObserver extends Observer{
 
        public EmailObserver(Account _account){
            this.account = _account;
            this.account.attach(this);
        }
        public void update(){
            System.out.println("Email sent");
        }
        
    
}
