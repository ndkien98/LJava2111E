/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demoproxypattern;

/**
 *
 * @author KhuongVD1
 */
public class ProxyImage implements Image{
    private Image realImage;
    private String url;
    
    public ProxyImage(String _url){
        this.url = _url;
        System.out.println("Image unloaded: " + this.url);
    }
    public void showImage(){
        if(realImage == null){
            realImage = new RealImage(this.url);
        }else{
            System.out.println("Image existed: " + this.url);
        }
        realImage.showImage();
    }
}
